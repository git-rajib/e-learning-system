import { PrismaClient } from "@prisma/client";

// Create a new Prisma client
const prisma = new PrismaClient();

async function seeder() {
  // Seed the database with some categories
  const categories = [
    { name: "Computer Science" },
    { name: "Music" },
    { name: "Fitness" },
    { name: "Photography" },
    { name: "Accounting" },
    { name: "Engineering" },
    { name: "Filming" },
  ];

  // Insert the categories into the database
  await prisma.category.createMany({
    data: categories,
  });
}

// Run the seeder function
seeder()
  .then(async () => {
    await prisma.$disconnect();
  })
  .catch(async e => {
    console.error(e);
    await prisma.$disconnect();
    process.exit(1);
  });
