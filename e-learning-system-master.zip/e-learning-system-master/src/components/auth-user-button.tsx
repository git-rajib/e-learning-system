"use client";

import Image from "next/image";
import { useRouter } from "next/navigation";
import { useClerk, useUser } from "@clerk/nextjs";
import { LayoutDashboard, LoaderIcon, LogOut, UserIcon } from "lucide-react";

import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuPortal,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const UserDropdownMenu = () => {
  const router = useRouter();
  const { user } = useUser();
  const { signOut, openUserProfile } = useClerk();

  return (
    <DropdownMenu>
      <DropdownMenuTrigger
        asChild
        className="outline-none"
      >
        <Button
          variant="link"
          className="h-9 py-2 w-9 px-0 cursor-pointer rounded-full ring-1 ring-primary/50 outline-none"
        >
          {user?.hasImage ? (
            <Image
              alt="profile_image"
              src={user?.imageUrl}
              width={30}
              height={30}
              className="rounded-full drop-shadow-sm"
            />
          ) : (
            <UserIcon className="h-6 w-auto" />
          )}
        </Button>
      </DropdownMenuTrigger>

      <DropdownMenuPortal>
        <DropdownMenuContent className="mt-4 w-52 rounded-lg border border-border bg-white px-2 py-2 drop-shadow-2xl">
          <DropdownMenuItem asChild>
            <Button
              size="sm"
              variant="ghost"
              onClick={() => openUserProfile()}
              className="w-full justify-start text-slate-700 cursor-pointer"
            >
              <UserIcon className="mr-2 h-4 w-auto" />
              Profile
            </Button>
          </DropdownMenuItem>

          <DropdownMenuItem asChild>
            <Button
              size="sm"
              variant="ghost"
              className="w-full justify-start text-slate-700 cursor-pointer"
              onClick={() => router.push("/dashboard")}
            >
              <LayoutDashboard className="mr-2 h-4 w-auto" />
              Dashboard
            </Button>
          </DropdownMenuItem>

          <DropdownMenuItem asChild>
            <Button
              size="sm"
              variant="ghost"
              onClick={() => signOut(() => router.push("/"))}
              className="w-full justify-start text-slate-700 cursor-pointer"
            >
              <LogOut className="mr-2 h-4 w-auto" />
              Sign Out
            </Button>
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenuPortal>
    </DropdownMenu>
  );
};

export const UserButton = () => {
  const { isLoaded, user } = useUser();
  const { openSignIn, openSignUp } = useClerk();

  if (!isLoaded) {
    return (
      <Button
        variant="link"
        className="h-9 py-2 w-9 px-0 cursor-pointer rounded-full ring-1 ring-primary/50 outline-none"
        onClick={() => openSignIn()}
      >
        <LoaderIcon className="h-6 w-auto animate-spin" />
      </Button>
    );
  }

  if (!user?.id) {
    return (
      <>
        <Button
          size="sm"
          variant="outline"
          onClick={() => openSignIn()}
        >
          Login
        </Button>

        <Button
          size="sm"
          variant="outline"
          onClick={() => openSignUp()}
        >
          Register
        </Button>
      </>
    );
  }

  return <UserDropdownMenu />;
};
