const AboutUsPage = () => {
  return (
    <>
      <section className="py-10">
        <div className="container">
          <div className="section-info mb-8">
            <h1 className="mb-2 font-bold text-center text-2xl lg:mb-4 sm:text-3xl md:text-4xl lg:text-5xl">
              About Us
            </h1>

            <p className="text-sm md:text-base lg:text-lg text-center text-gray-500">
              Learn more about us and our mission
            </p>
          </div>
        </div>
      </section>
    </>
  );
};

export default AboutUsPage;
