export const navigations = [
  {
    title: "Home",
    href: "/",
  },
  {
    title: "Courses",
    href: "/courses",
  },
  {
    title: "About Us",
    href: "/about-us",
  },
];

export const footerNavigations = [
  {
    title: "Terms & Conditions",
    href: "/terms",
  },
  {
    title: "Refund Policy",
    href: "/refund-policy",
  },
  {
    title: "Privacy Policy",
    href: "/privacy-policy",
  },
];
