import Image from "next/image";
import Link from "next/link";
import { PlayCircleIcon } from "lucide-react";

import Categories from "./_components/categories";
import HomepageCourses from "./_components/homepage-courses";

export default async function HomePage() {
  return (
    <>
      <section className="py-10 sm:py-16 lg:py-24 bg-slate-400/5">
        <div className="container">
          <div className="grid items-center grid-cols-1 gap-12 lg:grid-cols-2">
            <div>
              <h1 className="text-4xl font-bold sm:text-6xl lg:text-7xl">
                <div className="relative inline-flex">
                  <span className="absolute inset-x-0 bottom-0 border-b-[30px] border-green-200"></span>
                  <h1 className="relative text-4xl font-bold sm:text-6xl lg:text-7xl">
                    Skills
                  </h1>
                </div>
                <span className="ml-3">that drive you forward</span>
              </h1>

              <p className="mt-8 text-base sm:text-xl">
                Technology and the world of work change fast — with us, you’re
                faster. Get the skills to achieve goals and stay competitive.
              </p>

              <div className="mt-10 flex items-center gap-5 md:gap-0 sm:flex sm:items-center sm:space-x-8">
                <Link
                  href="/courses"
                  className="inline-flex items-center justify-center px-10 py-4 text-base font-semibold text-white transition-all duration-200 bg-primary hover:bg-green-700 focus:bg-green-700"
                >
                  Get Started
                </Link>

                <button className="inline-flex items-center text-base font-semibold transition-all duration-200 sm:mt-0 hover:opacity-80">
                  <PlayCircleIcon className="w-10 h-10 mr-3 text-green-700" />
                  Watch video
                </button>
              </div>
            </div>

            <div className="flex justify-center lg:justify-end">
              <Image
                width={409}
                height={522}
                src="/woman-young-free-clipart-hd.png"
                alt="Woman"
              />
            </div>
          </div>
        </div>
      </section>

      <section className="py-10 sm:py-16 lg:py-24">
        <div className="container">
          <div className="section-info mb-8">
            <h1 className="mb-2 font-bold text-center text-2xl lg:mb-6 sm:text-3xl md:text-4xl lg:text-5xl">
              A broad selection of courses
            </h1>

            <p className="text-sm md:text-base lg:text-lg text-center text-gray-500">
              Choose from over 210,000 online video courses with new additions
              published every month
            </p>
          </div>

          <HomepageCourses />
        </div>
      </section>

      <section className="py-10 sm:py-16 lg:py-24 bg-slate-400/5">
        <div className="container">
          <div className="section-info mb-8">
            <h1 className="mb-2 font-bold text-center text-2xl lg:mb-6 sm:text-3xl md:text-4xl lg:text-5xl">
              Top categories
            </h1>

            <p className="text-sm md:text-base lg:text-lg text-center text-gray-500">
              Explore categories and find the right course for you
            </p>
          </div>

          <Categories />
        </div>
      </section>

      <section className="py-10 sm:py-16 lg:py-24">
        <div className="container">
          <div className="flex flex-col gap-y-10 lg:mx-auto lg:max-w-[70%] lg:flex-row">
            <div className="relative w-full text-right">
              <Image
                width={400}
                height={400}
                src="/images/become-instructor.jpg"
                alt="Woman"
              />
            </div>

            <div className="w-full self-center p-6">
              <div className="mb-8 space-y-5 lg:space-y-6">
                <h1 className="font-bold text-2xl sm:text-3xl md:text-4xl">
                  Become an instructor
                </h1>

                <p className="text-sm md:text-base text-gray-500">
                  Instructors from around the world teach millions of learners
                  on SkillMentor. We provide the tools and skills to teach what
                  you love.
                </p>

                <Link
                  href="/"
                  className="inline-flex items-center justify-center px-10 py-4 text-base font-semibold text-white transition-all duration-200 bg-primary hover:bg-green-700 focus:bg-green-700"
                >
                  Get Started
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
