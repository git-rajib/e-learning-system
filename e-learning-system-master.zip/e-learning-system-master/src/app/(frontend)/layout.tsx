import FrontendFooter from "./_components/footer";
import FrontendHeader from "./_components/header";

const FrontendLayout = ({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) => {
  return (
    <div className="main-layout__wrap">
      <FrontendHeader />
      <main className="lg:min-h-[calc(100vh_-_130px)]">{children}</main>
      <FrontendFooter />
    </div>
  );
};

export default FrontendLayout;
