import { getCourses } from "@/actions/get-courses";
import { SearchInput } from "@/components/search-input";
import { db } from "@/lib/db";

import { Categories } from "./courses-categories";
import { CoursesList } from "./courses-list";

interface CoursesProps {
  searchParams: {
    title: string;
    categoryId: string;
  };
}

const Courses = async ({ searchParams }: CoursesProps) => {
  const categories = await db.category.findMany({
    orderBy: {
      name: "asc",
    },
  });

  const courses = await getCourses(searchParams);

  return (
    <>
      <div className="px-6 pt-6 block">
        <SearchInput />
      </div>

      <div className="p-6 space-y-4">
        <Categories items={categories} />
        <CoursesList items={courses} />
      </div>
    </>
  );
};

export default Courses;
