import Courses from "./_components/courses-with-filter";

const CoursesPage = ({
  searchParams,
}: {
  searchParams: {
    title: string;
    categoryId: string;
  };
}) => {
  return (
    <>
      <section className="py-10">
        <div className="container">
          <div className="section-info mb-8">
            <h1 className="mb-2 font-bold text-center text-2xl lg:mb-4 sm:text-3xl md:text-4xl lg:text-5xl">
              Our Courses
            </h1>

            <p className="text-sm md:text-base lg:text-lg text-center text-gray-500">
              Choose from a wide range of courses to help you achieve your goals
            </p>
          </div>
        </div>

        <div className="container mt-10">
          <Courses searchParams={searchParams} />
        </div>
      </section>
    </>
  );
};

export default CoursesPage;
