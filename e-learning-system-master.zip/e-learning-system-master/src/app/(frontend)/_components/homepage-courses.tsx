import Link from "next/link";

import { getCourses } from "@/actions/get-courses";
import { CoursesList } from "@/components/courses-list";

const HomepageCourses = async () => {
  const courses = await getCourses({
    limit: 6,
  });

  if (courses.length === 0) {
    return (
      <div className="text-center">
        <p>Currently, we don&apos;t have any courses!</p>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-4">
      <CoursesList items={courses} />

      <div className="text-center pt-8">
        <Link
          href="/courses"
          className="inline-flex items-center justify-center px-10 py-4 text-base font-semibold text-white transition-all duration-200 bg-primary hover:bg-purple-700 focus:bg-purple-700"
        >
          View all courses
        </Link>
      </div>
    </div>
  );
};

export default HomepageCourses;
