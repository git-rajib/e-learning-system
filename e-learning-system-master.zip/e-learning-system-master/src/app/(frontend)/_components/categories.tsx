import Link from "next/link";
import { IconType } from "react-icons";
import {
  FcEngineering,
  FcFilmReel,
  FcMultipleDevices,
  FcMusic,
  FcOldTimeCamera,
  FcSalesPerformance,
  FcSportsMode,
} from "react-icons/fc";
import { Category } from "@prisma/client";

import { db } from "@/lib/db";

const iconMap: Record<Category["name"], IconType> = {
  Music: FcMusic,
  Photography: FcOldTimeCamera,
  Fitness: FcSportsMode,
  Accounting: FcSalesPerformance,
  "Computer Science": FcMultipleDevices,
  Filming: FcFilmReel,
  Engineering: FcEngineering,
};

const Categories = async () => {
  const categories = await db.category.findMany({
    orderBy: {
      name: "asc",
    },
  });

  return (
    <div className="grid grid-cols-2 gap-6 sm:grid-cols-3 lg:grid-cols-4">
      {categories.map(category => {
        const Icon = iconMap[category.name];

        return (
          <Link
            key={category.id}
            href={`/courses?categoryId=${category.id}`}
            className="flex items-center p-4 space-x-3 transition-all duration-200 border border-transparent rounded-lg hover:border-green-700"
          >
            <div className="flex items-center justify-center w-12 h-12 bg-green-200 rounded-full">
              {Icon && <Icon size={20} />}
            </div>

            <span className="text-sm font-semibold text-gray-700">
              {category.name}
            </span>
          </Link>
        );
      })}
    </div>
  );
};

export default Categories;
