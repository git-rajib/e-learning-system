import Image from "next/image";
import Link from "next/link";
import { Menu } from "lucide-react";

import Logo from "@/../public/images/logo.svg";
import { UserButton } from "@/components/auth-user-button";
import { HOMEPAGE_ROUTE } from "@/configs/routes";

import HeaderNavigations from "./header-navigations";

const FrontendHeader = () => {
  return (
    <header className="border-general sticky top-0 z-40 border-b bg-slate-50/60 backdrop-blur-2xl transition-colors duration-500">
      <div className="container">
        <div className="relative flex h-16 items-center justify-between">
          <div className="flex items-center lg:px-0">
            <div className="flex flex-shrink-0 items-center">
              <Link
                href={HOMEPAGE_ROUTE}
                className="flex items-center"
              >
                <Image
                  src={Logo}
                  alt="Logo"
                  className="w-32"
                />
              </Link>
            </div>
          </div>

          <div className="flex space-x-2 lg:hidden">
            <div className="text-primary ml-auto flex flex-shrink-0 items-center p-1 border border-border rounded-sm transition-all duration-200 focus:bg-secondary hover:bg-secondary focus:outline-none">
              <Menu />
            </div>
          </div>

          <div className="hidden lg:flex lg:items-center lg:space-x-4">
            <div className="flex space-x-2">
              <HeaderNavigations />
            </div>

            <div className="hidden lg:block">
              <div className="flex items-center space-x-4">
                <UserButton />
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default FrontendHeader;
