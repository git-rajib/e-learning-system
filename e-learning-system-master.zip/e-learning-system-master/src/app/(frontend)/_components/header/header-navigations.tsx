"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

import { cn } from "@/lib/utils";

import { navigations } from "../../navigations";

const HeaderNavigations = () => {
  const pathname = usePathname();

  return navigations.map(nav => (
    <Link
      key={nav.title}
      href={nav.href}
      className={cn(
        "text-slate-700 hover:underline hover:underline-offset-8 px-3 py-2 text-sm font-medium",
        pathname === nav.href && "underline text-primary underline-offset-8"
      )}
    >
      {nav.title}
    </Link>
  ));
};

export default HeaderNavigations;
