import FooterNavigations from "./footer-navigations";

const FrontendHeader = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="w-full pt-3.5 block border-general border-t !pb-3.5">
      <div className="container">
        <div className="flex flex-col-reverse items-center justify-between gap-1 lg:flex-row">
          <p className="text-center text-xs sm:text-sm lg:text-left">
            Copyright ©{currentYear} E-Learning. All rights reserved.
          </p>

          <div className="flex space-x-2 text-xs sm:text-sm lg:space-x-4">
            <FooterNavigations />
          </div>
        </div>
      </div>
    </footer>
  );
};

export default FrontendHeader;
