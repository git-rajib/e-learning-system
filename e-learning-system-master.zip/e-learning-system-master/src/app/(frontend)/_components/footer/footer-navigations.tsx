"use client";

import Link from "next/link";

import { cn } from "@/lib/utils";

import { footerNavigations } from "../../navigations";

const FooterNavigations = () => {
  return footerNavigations.map(nav => (
    <Link
      key={nav.title}
      href={nav.href}
      className={cn(
        "text-slate-700 hover:underline hover:underline-offset-8 px-3 py-2 text-sm font-medium"
      )}
    >
      {nav.title}
    </Link>
  ));
};

export default FooterNavigations;
