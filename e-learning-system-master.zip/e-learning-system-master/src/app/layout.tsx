import type { Metadata } from "next";
import { Poppins as FontSans } from "next/font/google";
import { ClerkProvider } from "@clerk/nextjs";

import { ConfettiProvider } from "@/components/providers/confetti-provider";
import { Toaster } from "@/components/ui/sonner";
import { cn } from "@/lib/utils";

import "@/styles/globals.css";

const fontSans = FontSans({
  subsets: ["latin"],
  weight: ["200", "400", "500", "600", "700", "900"],
  variable: "--font-sans",
});

export const metadata: Metadata = {
  title: "E-Learning System",
  description: "E-Learning System for students and teachers.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <ClerkProvider>
      <html lang="en">
        <body className={cn(fontSans.variable)}>
          <ConfettiProvider />
          <Toaster
            position="bottom-center"
            richColors
          />
          {children}
        </body>
      </html>
    </ClerkProvider>
  );
}
