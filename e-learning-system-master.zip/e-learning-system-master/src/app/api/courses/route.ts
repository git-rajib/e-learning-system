import { NextRequest, NextResponse } from "next/server";

import { getCourses } from "@/actions/get-courses";
import { getCurrentUserId } from "@/lib/auth";
import { db } from "@/lib/db";

export async function POST(req: NextRequest) {
  try {
    const { title } = await req.json();
    const { userId } = getCurrentUserId();

    if (!userId) {
      return new NextResponse("Unauthorized", { status: 401 });
    }

    const course = await db.course.create({
      data: {
        userId,
        title,
      },
    });

    return NextResponse.json(course);
  } catch (error) {
    console.log(error);

    return new NextResponse("Internal Server Error", { status: 500 });
  }
}

export async function GET(req: NextRequest) {
  try {
    const searchParams = req.nextUrl.searchParams;

    const { userId } = getCurrentUserId();
    const title = searchParams.get("title");
    const categoryId = searchParams.get("categoryId");

    if (!userId) {
      return new NextResponse("Unauthorized", { status: 401 });
    }

    if (!title || !categoryId) {
      return new NextResponse("Bad Request", { status: 400 });
    }

    const courses = await getCourses({
      userId,
      categoryId,
      title,
    });

    return NextResponse.json({ courses });
  } catch (error) {
    return NextResponse.json({ courses: [] });
  }
}
