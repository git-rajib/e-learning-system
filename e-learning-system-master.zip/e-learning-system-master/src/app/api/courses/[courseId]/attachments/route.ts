import { NextResponse } from "next/server";

import { getCurrentUserId } from "@/lib/auth";
import { db } from "@/lib/db";

export async function POST(
  req: Request,
  { params }: { params: { courseId: string } }
) {
  try {
    const { userId } = getCurrentUserId();
    const { url, originalFilename } = await req.json();

    if (!userId) {
      return new NextResponse("Unauthorized", { status: 401 });
    }

    const courseOwner = await db.course.findUnique({
      where: {
        id: params.courseId,
        userId: userId,
      },
    });

    if (!courseOwner) {
      return new NextResponse("Unauthorized", { status: 401 });
    }

    let name = url ? url.split("/").pop() : "Untitled";

    if (originalFilename) {
      name = originalFilename;
    }

    const attachment = await db.attachment.create({
      data: {
        url,
        name,
        courseId: params.courseId,
      },
    });

    return NextResponse.json(attachment);
  } catch (error) {
    return new NextResponse("Internal Server Error", { status: 500 });
  }
}
