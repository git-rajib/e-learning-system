import { NextRequest, NextResponse } from "next/server";

import { getProgress } from "@/actions/get-progress";
import { getCurrentUserId } from "@/lib/auth";

export async function GET(
  req: NextRequest,
  { params }: { params: { courseId: string } }
) {
  try {
    const { courseId } = params;
    const { userId } = getCurrentUserId();

    if (!userId) {
      return new NextResponse("Unauthorized", { status: 401 });
    }

    const progress = await getProgress(userId, courseId);
    return NextResponse.json({ progress });
  } catch (error) {
    return NextResponse.json({
      progress: 0,
    });
  }
}
