import { NextResponse } from "next/server";

import { getCurrentUserId } from "@/lib/auth";
import { db } from "@/lib/db";

export async function PATCH(
  req: Request,
  { params }: { params: { id: string } }
) {
  try {
    const { ...values } = await req.json();
    const { userId } = getCurrentUserId();

    if (!userId) {
      return new NextResponse("Unauthorized", { status: 401 });
    }

    const userProfile = await db.profile.findUnique({
      where: {
        userId,
      },
    });

    if (!userProfile) {
      return new NextResponse("Unauthorized", { status: 401 });
    }

    const profile = await db.profile.update({
      where: {
        id: params.id,
      },
      data: {
        ...values,
      },
    });

    return NextResponse.json(profile);
  } catch (error) {
    return new NextResponse("Internal Server Error", { status: 500 });
  }
}
