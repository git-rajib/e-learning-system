import { createUploadthing, type FileRouter } from "uploadthing/next";

import { authenticateFileUpload } from "@/lib/auth";

// Create an instance of the uploadthing
const file = createUploadthing();

// This function is called when the file upload is complete
const handleUploadComplete = () => {};

// Profile image upload route
const profileImageUploadRoute = file({
  image: {
    maxFileSize: "4MB",
    maxFileCount: 1,
  },
})
  .middleware(() => authenticateFileUpload())
  .onUploadComplete(handleUploadComplete);

// Course image upload route
const courseImageUploadRoute = file({
  image: {
    maxFileSize: "4MB",
    maxFileCount: 1,
  },
})
  .middleware(() => authenticateFileUpload())
  .onUploadComplete(handleUploadComplete);

// Course attachments upload route
const courseAttachmentsUploadRoute = file([
  "text",
  "image",
  "video",
  "audio",
  "pdf",
])
  .middleware(() => authenticateFileUpload())
  .onUploadComplete(handleUploadComplete);

// Course chapter video upload route
const courseChapterVideoUploadRoute = file({
  video: {
    maxFileSize: "512GB",
    maxFileCount: 1,
  },
})
  .middleware(() => authenticateFileUpload())
  .onUploadComplete(handleUploadComplete);

export const fileUploadRouter = {
  profileImage: profileImageUploadRoute,
  courseImage: courseImageUploadRoute,
  courseAttachment: courseAttachmentsUploadRoute,
  chapterVideo: courseChapterVideoUploadRoute,
} satisfies FileRouter;

export type FileUploadRouter = typeof fileUploadRouter;
