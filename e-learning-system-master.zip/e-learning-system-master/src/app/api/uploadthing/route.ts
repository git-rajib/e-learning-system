import { createRouteHandler } from "uploadthing/next";

// Uploadthing routes
import { fileUploadRouter } from "./core";

// Export the route handlers
export const { GET, POST } = createRouteHandler({
  router: fileUploadRouter,
});
