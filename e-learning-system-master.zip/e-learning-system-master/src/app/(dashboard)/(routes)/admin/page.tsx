const AdminHomePage = () => {
  return (
    <div>
      <h1>Admin Home Page</h1>
    </div>
  );
};

export default AdminHomePage;
