import { db } from "@/lib/db";

import { columns } from "./_components/columns";
import { DataTable } from "./_components/data-table";

const UsersPage = async () => {
  const userData = await db.profile.findMany();

  return (
    <div className="p-6">
      <h1>Users</h1>
      <DataTable
        columns={columns}
        data={userData}
      />
    </div>
  );
};

export default UsersPage;
