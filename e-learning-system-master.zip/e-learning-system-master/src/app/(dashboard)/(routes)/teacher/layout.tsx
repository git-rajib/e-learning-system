import { redirect } from "next/navigation";
import { MemberRole } from "@prisma/client";

import getSafeProfile from "@/actions/get-safe-profile";

const DashboardLayout = async ({ children }: { children: React.ReactNode }) => {
  const profile = await getSafeProfile();

  if (!profile || profile.role !== MemberRole.TEACHER) {
    return redirect("/");
  }

  return children;
};

export default DashboardLayout;
