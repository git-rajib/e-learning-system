import { redirect } from "next/navigation";
import { auth } from "@clerk/nextjs/server";

import { db } from "@/lib/db";

import { columns } from "./_components/columns";
import { DataTable } from "./_components/data-table";

const CoursesPage = async () => {
  const userId = auth();

  if (!userId) {
    return redirect("/");
  }

  // Remove the getToken property from the userId object.
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { getToken, ...userIdWithoutToken } = userId;

  const courses = await db.course.findMany({
    where: {
      userId: userIdWithoutToken.userId || undefined,
    },
    orderBy: {
      createdAt: "desc",
    },
  });

  return (
    <div className="p-6">
      <DataTable
        columns={columns}
        data={courses}
      />
    </div>
  );
};

export default CoursesPage;
