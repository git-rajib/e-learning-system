import { redirect } from "next/navigation";

import { getProgress } from "@/actions/get-progress";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/lib/db";

import { CourseNavbar } from "./_components/course-navbar";
import { CourseSidebar } from "./_components/course-sidebar";

const CourseLayout = async ({
  children,
  params,
}: {
  children: React.ReactNode;
  params: { courseId: string };
}) => {
  const currentUser = await getCurrentUser();

  const course = await db.course.findUnique({
    where: {
      id: params.courseId,
    },
    include: {
      chapters: {
        where: {
          isPublished: true,
        },
        include: {
          userProgress: {
            where: {
              userId: currentUser.id,
            },
          },
        },
        orderBy: {
          position: "asc",
        },
      },
    },
  });

  if (!course) {
    return redirect("/");
  }

  const progressCount = await getProgress(currentUser.id, course.id);

  return (
    <div className="h-full">
      <div className="hidden md:mt-[80px] md:flex h-full w-80 flex-col fixed inset-y-0 z-[9999]">
        <CourseSidebar
          course={course}
          progressCount={progressCount || 0}
        />
      </div>
      <div className="md:pl-80 h-full">
        <div className="w-full z-[999]">
          <CourseNavbar
            course={course}
            progressCount={progressCount || 0}
          />
        </div>
        {children}
      </div>
    </div>
  );
};

export default CourseLayout;
