"use client";

import { MemberRole, Profile } from "@prisma/client";
import { BarChart, Layout, List } from "lucide-react";

import SidebarItem from "./sidebar-item";

const studentRoutes = [
  {
    icon: Layout,
    label: "Dashboard",
    href: "/dashboard",
  },
];

const adminRoutes = [
  {
    icon: Layout,
    label: "Dashboard",
    href: "/dashboard",
  },
  {
    icon: List,
    label: "Users",
    href: "/admin/users",
  },
];

const teacherRoutes = [
  {
    icon: Layout,
    label: "Dashboard",
    href: "/dashboard",
  },
  {
    icon: List,
    label: "Courses",
    href: "/teacher/courses",
  },
  {
    icon: BarChart,
    label: "Analytics",
    href: "/teacher/analytics",
  },
];

type SidebarRoutesProps = {
  currentUser: Profile;
};

export const SidebarRoutes = ({ currentUser }: SidebarRoutesProps) => {
  let routes = studentRoutes;

  if (currentUser?.role === MemberRole.TEACHER) {
    routes = teacherRoutes;
  }

  if (currentUser?.role === MemberRole.ADMIN) {
    routes = adminRoutes;
  }

  return (
    <div className="flex flex-col w-full">
      {routes.map((route, index) => (
        <SidebarItem
          key={index}
          icon={route.icon}
          label={route.label}
          href={route.href}
        />
      ))}
    </div>
  );
};
