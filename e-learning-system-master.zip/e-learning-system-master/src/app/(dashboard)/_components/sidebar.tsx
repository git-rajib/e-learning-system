"use client";

import Image from "next/image";
import Link from "next/link";
import { Profile } from "@prisma/client";

import Logo from "@/../public/images/logo.svg";

import { SidebarRoutes } from "./sidebar-routes";

type SidebarProps = {
  currentUser: Profile;
};

export const Sidebar = ({ currentUser }: SidebarProps) => {
  return (
    <div className="h-full border-r flex flex-col overflow-y-auto bg-white text-gray-900 shadow-sm dark:bg-gray-900 dark:text-white">
      <div className="p-6">
        <Link
          href="/"
          className="cursor-pointer"
          passHref
        >
          <Image
            src={Logo}
            alt="Logo"
            className="w-32"
          />
        </Link>
      </div>

      <div className="flex flex-col w-full">
        <SidebarRoutes currentUser={currentUser} />
      </div>
    </div>
  );
};
