import { redirect } from "next/navigation";

import { getCurrentUserId } from "@/lib/auth";
import { db } from "@/lib/db";
import { SafeProfile } from "@/types";

export default async function getSafeProfile() {
  try {
    const { userId } = getCurrentUserId();

    if (!userId) {
      return redirect("/");
    }

    const currentProfile = await db.profile.findUnique({
      where: {
        userId,
      },
      select: {
        id: true,
        userId: true,
        name: true,
        imageUrl: true,
        email: true,
        role: true,
        createdAt: true,
        updatedAt: true,
      },
    });

    if (!currentProfile) {
      return null;
    }

    // Convert createdAt and updatedAt to ISO strings
    const safeProfile: SafeProfile = {
      ...currentProfile,
      createdAt: currentProfile.createdAt.toISOString(),
      updatedAt: currentProfile.updatedAt.toISOString(),
    };

    return safeProfile;
  } catch (error: unknown) {
    return null;
  }
}
