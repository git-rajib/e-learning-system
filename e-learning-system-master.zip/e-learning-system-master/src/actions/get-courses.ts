import { getProgress } from "@/actions/get-progress";
import { db } from "@/lib/db";
import { CourseWithProgressWithCategory } from "@/types";

type GetCourses = {
  userId?: string;
  title?: string;
  categoryId?: string;
  limit?: number;
};

export const getCourses = async ({
  userId,
  title,
  categoryId,
  limit,
}: GetCourses): Promise<CourseWithProgressWithCategory[]> => {
  try {
    const courses = await db.course.findMany({
      where: {
        isPublished: true,
        title: {
          contains: title,
          mode: "insensitive",
        },
        categoryId,
      },
      include: {
        category: true,
        chapters: {
          where: {
            isPublished: true,
          },
          select: {
            id: true,
          },
        },
        purchases: {
          where: {
            userId,
          },
        },
      },
      orderBy: {
        createdAt: "desc",
      },
      ...(limit && { take: limit }),
    });

    const coursesWithProgress: CourseWithProgressWithCategory[] =
      await Promise.all(
        courses.map(async course => {
          if (course.purchases.length === 0) {
            return {
              ...course,
              progress: null,
            };
          }

          let progressPercentage: number | null = null;

          if (userId) {
            progressPercentage = await getProgress(userId, course.id);
          }

          return {
            ...course,
            progress: progressPercentage,
          };
        })
      );

    return coursesWithProgress;
  } catch (error) {
    return [];
  }
};
