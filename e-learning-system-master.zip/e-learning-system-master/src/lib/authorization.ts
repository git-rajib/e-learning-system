import { getCurrentUser } from "./auth";

export const isCurrentUserTeacher = async () => {
  const user = await getCurrentUser();

  if (!user) {
    return false;
  }

  return user.role === "TEACHER";
};

export const isCurrentUserStudent = async () => {
  const user = await getCurrentUser();

  if (!user) {
    return false;
  }

  return user.role === "STUDENT";
};

export const isCurrentUserAdmin = async () => {
  const user = await getCurrentUser();

  if (!user) {
    return false;
  }

  return user.role === "ADMIN";
};
