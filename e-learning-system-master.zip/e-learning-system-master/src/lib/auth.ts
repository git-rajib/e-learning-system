import {
  auth,
  currentUser as currentAuthenticatedUser,
} from "@clerk/nextjs/server";
import { MemberRole } from "@prisma/client";

import { db } from "./db";

export const authenticateFileUpload = () => {
  const authObject = auth();

  if (!authObject?.userId) {
    throw new Error("Unauthorized");
  }

  return { userId: authObject.userId };
};

export const getCurrentUserId = () => {
  const authObject = auth();
  return { userId: authObject?.userId || null };
};

export const getCurrentUserRaw = async () => {
  const user = await currentAuthenticatedUser();
  return user;
};

export const getCurrentUser = async () => {
  const user = await currentAuthenticatedUser();
  const authObject = auth();

  if (!user) {
    return authObject.redirectToSignIn();
  }

  const profile = await db.profile.findUnique({
    where: {
      userId: user.id,
    },
  });

  if (profile) {
    return profile;
  }

  let firstName = user.firstName || "";
  let lastName = user.lastName || "";

  if (!firstName && !lastName) {
    const emailParts = user.emailAddresses[0].emailAddress.split("@");
    firstName = emailParts[0].trim();
    lastName = "";
  }

  return await db.profile.create({
    data: {
      userId: user.id,
      name: `${firstName} ${lastName}`,
      imageUrl: user.imageUrl,
      email: user.emailAddresses[0].emailAddress,
      role: MemberRole.STUDENT,
    },
  });
};
