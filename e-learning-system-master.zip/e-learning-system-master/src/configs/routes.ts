export const HOMEPAGE_ROUTE = "/";
export const ADMIN_DASHBOARD_ROUTE = "/admin";
export const TEACHER_DASHBOARD_ROUTE = "/teacher";
export const STUDENT_DASHBOARD_ROUTE = "/dashboard";
export const COURSE_ACCESS_ROUTE = "/course";
